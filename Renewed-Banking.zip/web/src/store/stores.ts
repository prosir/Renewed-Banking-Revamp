import { writable } from "svelte/store"

export const visibility = writable(false)
export const loading = writable(false)
export const notify = writable<
  | string
  | {
      message: string
      title?: string
      type?: "success" | "error" | "info"
    }
>("")
export const activeAccount = writable(null)
export const atm = writable(false)
export const currency = writable("USD")

export const popupDetails = writable({
  account: {},
  actionType: "",
})

// Initialize accounts with an empty array to prevent undefined errors
export const accounts = writable<any[]>([])

// Initialize translations with an empty object to prevent undefined errors
export const translations = writable<any>({})
