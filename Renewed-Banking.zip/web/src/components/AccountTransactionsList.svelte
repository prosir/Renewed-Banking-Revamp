<script>
    import { onMount } from 'svelte';
    import { transactions } from '../stores/transactionStore';
    import { selectedAccount } from '../stores/accountStore';
    import TransactionItem from './TransactionItem.svelte';
    import { formatDate } from '../utils/dateUtils';

    let loading = true;
    let accountTransactions = [];

    $: {
        if ($selectedAccount) {
            accountTransactions = $transactions.filter(transaction => transaction.accountId === $selectedAccount.id);
        } else {
            accountTransactions = [];
        }
    }

    onMount(async () => {
        // Simulate loading data (replace with actual data fetching)
        setTimeout(() => {
            loading = false;
        }, 500);
    });
</script>

<div class="container mx-auto p-4">
    {#if !$selectedAccount}
        <div class="text-center">
            <div class="w-20 h-20 mx-auto bg-fleeca-bg rounded-full flex items-center justify-center mb-6">
                <i class="fas fa-university text-fleeca-green text-3xl"></i>
            </div>
            <p class="text-gray-600">Select an account to view transactions.</p>
        </div>
    {:else}
        <h2 class="text-2xl font-bold mb-4">Transactions for {$selectedAccount.name}</h2>

        {#if loading}
            <p class="text-gray-500">Loading transactions...</p>
        {:else if accountTransactions.length === 0}
            <p class="text-gray-500">No transactions found for this account.</p>
        {:else}
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Date
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Description
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Amount
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        {#each accountTransactions as transaction (transaction.id)}
                            <TransactionItem {transaction} />
                        {/each}
                    </tbody>
                </table>
            </div>
        {/if}
    {/if}
</div>
