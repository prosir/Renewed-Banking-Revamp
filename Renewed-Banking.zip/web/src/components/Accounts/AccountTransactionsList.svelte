<script lang="ts">
  import { accounts, activeAccount, translations, atm, notify, popupDetails } from "../../store/stores";
  import AccountTransactionItem from "./AccountTransactionItem.svelte";
  import { convertToCSV } from "../../utils/convertToCSV";
  import { setClipboard } from "../../utils/setClipboad";
  import { formatMoney } from "../../utils/misc";
  import { get } from 'svelte/store';
  import { onMount } from 'svelte';
  
  let transSearch = '';
  let balanceElement;
  let isBalanceAnimated = false;
  
  $: account = $activeAccount && $accounts && Array.isArray($accounts) 
      ? $accounts.find((accountItem: any) => $activeAccount === accountItem?.id) 
      : null;

  // Function to animate the balance when it changes
  function animateBalance() {
    if (balanceElement && !isBalanceAnimated) {
      isBalanceAnimated = true;
      balanceElement.classList.add('animate-glow');
      setTimeout(() => {
        balanceElement.classList.remove('animate-glow');
        isBalanceAnimated = false;
      }, 2000);
    }
  }

  // Watch for account changes to trigger animation
  $: if (account) {
    setTimeout(() => animateBalance(), 300);
  }

  function handleClickExportData() {
      if (!account) {
          console.log("No card selected");
          notify.set("No card selected!");
          setTimeout(() => {
              notify.set("");
          }, 3500);
          return;
      }
      
      if (!account.transactions || !Array.isArray(account.transactions) || account.transactions.length === 0) {
          notify.set("No transactions to export!");
          setTimeout(() => {
              notify.set("");
          }, 3500);
          return;
      }
      
      const csv = convertToCSV(account.transactions);
      setClipboard(csv);
      notify.set("Data copied to clipboard!");
      setTimeout(() => {
          notify.set("");
      }, 3500);
  }
  
  let isAtm: boolean = false;
  atm.subscribe((usingAtm: boolean) => {
      isAtm = usingAtm;
  });
  
  function handleButton(id:string, type:string) {
      const $accounts = get(accounts);
      if (!$accounts || !Array.isArray($accounts)) return;
      let account = $accounts.find((accountItem: any) => id === accountItem?.id);
      if (!account) return;
      popupDetails.update(() => ({ actionType: type, account }));
  }

  // Function to create animated digits for the balance
  function createAnimatedBalance(amount) {
    if (!amount && amount !== 0) return '';
    
    const formattedAmount = formatMoney(amount);
    let html = '<div class="money-counter">';
    
    // Convert the formatted amount to an array of characters
    const chars = formattedAmount.split('');
    
    // Create animated spans for each digit
    chars.forEach((char, index) => {
      html += `<span class="digit" style="--digit-index: ${index}">${char}</span>`;
    });
    
    html += '</div>';
    return html;
  }
</script>

<section class="flex-1 overflow-hidden flex flex-col">
  {#if account}
    <!-- Central balance display -->
    <div class="bg-fleeca-card p-6 rounded-lg mb-5 shadow-card text-center clean-card border border-fleeca-border relative overflow-hidden">
        <!-- Background accent -->
        <div class="absolute top-0 left-0 w-full h-1 bg-fleeca-green"></div>
        
        <h2 class="text-lg font-medium text-fleeca-text-secondary mb-2">{$translations.balance || 'Card Balance'}</h2>
        
        <!-- Animated balance display -->
        <div 
            bind:this={balanceElement} 
            class="balance-display text-5xl font-bold text-fleeca-text font-display mb-4 transition-all"
        >
            {@html createAnimatedBalance(account.amount)}
        </div>
        
        <!-- Account info -->
        <div class="flex justify-center items-center text-fleeca-text-secondary text-sm">
            <span class="mr-2">{account.name}</span>
            <span class="mx-2">•</span>
            <span>{account.id}</span>
        </div>
        
        <!-- Action buttons -->
        {#if !account.isFrozen}
            <div class="grid grid-cols-3 gap-3 mt-6">
                {#if !isAtm}
                    <button 
                        class="py-3 px-4 bg-fleeca-green text-white rounded-md text-sm font-medium hover:bg-fleeca-dark-green transition-colors" 
                        on:click={() => handleButton(account.id, "deposit")}
                    >
                        <i class="fas fa-arrow-down text-white mr-1"></i> {$translations.deposit_but || 'Deposit'}
                    </button>
                {/if}
                <button 
                    class="py-3 px-4 bg-fleeca-card text-fleeca-text rounded-md text-sm font-medium hover:bg-fleeca-hover transition-colors border border-fleeca-border" 
                    on:click={() => handleButton(account.id, "withdraw")}
                >
                    <i class="fas fa-arrow-up text-fleeca-text mr-1"></i> {$translations.withdraw_but || 'Withdraw'}
                </button>
                <button 
                    class="py-3 px-4 bg-fleeca-card text-fleeca-text rounded-md text-sm font-medium hover:bg-fleeca-hover transition-colors border border-fleeca-border" 
                    class:col-span-2={isAtm}
                    on:click={() => handleButton(account.id, "transfer")}
                >
                    <i class="fas fa-exchange-alt text-fleeca-text mr-1"></i> {$translations.transfer_but || 'Transfer'}
                </button>
            </div>
        {:else}
            <div class="text-center py-3 bg-red-900/30 rounded-lg text-red-400 font-medium border border-red-800/50 mt-6">
                <i class="fa-solid fa-lock mr-2"></i> {$translations.frozen || 'Card Status: Frozen'}
            </div>
        {/if}
    </div>
    
    <!-- Transactions section -->
    <div class="mb-4 flex justify-between items-center">
        <h3 class="text-2xl font-semibold text-fleeca-text flex items-center font-display">
            <div class="w-10 h-10 rounded-lg bg-fleeca-green/10 flex items-center justify-center mr-3 border border-fleeca-green/20">
                <i class="fa-solid fa-receipt text-fleeca-green"></i>
            </div>
            {$translations.transactions || 'Transactions'}
        </h3>
        
        {#if !isAtm && account.transactions && account.transactions.length > 0}
            <button 
                class="py-1 px-3 bg-fleeca-card text-fleeca-text-secondary rounded-md text-xs font-medium hover:bg-fleeca-hover transition-colors border border-fleeca-border flex items-center" 
                on:click|preventDefault={handleClickExportData}
            >
                <i class="fa-solid fa-file-export mr-1"></i>
                {$translations.export_data || 'Export Data'}
            </button>
        {/if}
    </div>
    
    <div class="relative mb-4">
        <input 
            type="text" 
            class="w-full rounded-lg border border-fleeca-border p-3 pl-10 bg-fleeca-bg text-fleeca-text focus:border-fleeca-green transition-all" 
            placeholder={$translations.trans_search || 'Search transactions...'} 
            bind:value={transSearch}
        >
        <i class="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-fleeca-text-secondary"></i>
    </div>
    
    <div class="overflow-y-auto flex-1 pr-2 hide-scrollbar">
        {#if account.transactions && Array.isArray(account.transactions) && account.transactions.length > 0}
            {#if account.transactions.filter(item => item && item.message && typeof item.message === 'string' && 
                (item.message.toLowerCase().includes((transSearch || '').toLowerCase()) || 
                (item.trans_id && typeof item.trans_id === 'string' && item.trans_id.toLowerCase().includes((transSearch || '').toLowerCase())) || 
                (item.receiver && typeof item.receiver === 'string' && item.receiver.toLowerCase().includes((transSearch || '').toLowerCase())))).length > 0}
            <div class="space-y-3 animate-fadeIn">
                {#each account.transactions.filter(item => item && item.message && typeof item.message === 'string' && 
                    (item.message.toLowerCase().includes((transSearch || '').toLowerCase()) || 
                    (item.trans_id && typeof item.trans_id === 'string' && item.trans_id.toLowerCase().includes((transSearch || '').toLowerCase())) || 
                    (item.receiver && typeof item.receiver === 'string' && item.receiver.toLowerCase().includes((transSearch || '').toLowerCase())))) as transaction (transaction.trans_id)}
                    <AccountTransactionItem {transaction}/>
                {/each}
            </div>
        {:else}
            <div class="text-center py-8 bg-fleeca-bg rounded-lg border border-fleeca-border animate-fadeIn shadow-card">
                <div class="w-16 h-16 mx-auto bg-fleeca-card rounded-full flex items-center justify-center mb-4">
                    <i class="fa-solid fa-receipt text-fleeca-text-secondary text-2xl"></i>
                </div>
                <h3 class="text-fleeca-text font-medium">{$translations && $translations.trans_not_found ? $translations.trans_not_found : 'No transactions found'}</h3>
            </div>
        {/if}
    {:else}
        <div class="text-center py-8 bg-fleeca-bg rounded-lg border border-fleeca-border animate-fadeIn shadow-card">
            <div class="w-16 h-16 mx-auto bg-fleeca-card rounded-full flex items-center justify-center mb-4">
                <i class="fa-solid fa-receipt text-fleeca-text-secondary text-2xl"></i>
            </div>
            <h3 class="text-fleeca-text font-medium">{$translations && $translations.trans_not_found ? $translations.trans_not_found : 'No transactions found'}</h3>
        </div>
    {/if}
</div>
{:else}
    <div class="flex-1 flex items-center justify-center">
        <div class="text-center py-12 px-6 bg-fleeca-card rounded-lg border border-fleeca-border animate-fadeIn max-w-md shadow-card">
            <div class="w-20 h-20 mx-auto bg-fleeca-bg rounded-full flex items-center justify-center mb-6">
                <i class="fas fa-credit-card text-fleeca-green text-3xl"></i>
            </div>
            <h3 class="text-fleeca-text font-medium text-xl mb-3 font-display">{$translations && $translations.select_account ? $translations.select_account : 'Select a card'}</h3>
            <p class="text-fleeca-text-secondary">Choose a card from the left to view details and manage your finances</p>
        </div>
    </div>
{/if}
</section>
